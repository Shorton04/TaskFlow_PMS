from django.shortcuts import render, get_object_or_404
from .models import Project, Task

def project_list(request):
    projects = Project.objects.filter(manager=request.user)
    return render(request, 'projects/project_list.html', {'projects': projects})

def project_detail(request, pk):
    project = get_object_or_404(Project, pk=pk)
    return render(request, 'projects/project_detail.html', {'project': project})

def task_detail(request, pk):
    task = get_object_or_404(Task, pk=pk)
    return render(request, 'projects/task_detail.html', {'task': task})